https://ieeexplore.ieee.org/document/9629958
Articulo: E. Hernández-González, P. Gómez-Gil, E. Bojorges-Valdez and M. Ramírez-Cortés, "Bi-dimensional representation of EEGs for BCI classification using CNN architectures," 2021 43rd Annual International Conference of the IEEE Engineering in Medicine & Biology Society (EMBC), 2021, pp. 767-770, doi: 10.1109/EMBC46164.2021.9629958.

https://inaoe.repositorioinstitucional.mx/jspui/handle/1009/2001
Tesis: Hernández González, E. M., (2020). Clasificación de señales EEG basada en representaciones bidimensionales y redes neuronales convolucionales, Tesis de Maestría, Instituto Nacional de Astrofísica, Óptica y Electrónica

Explicación del código: https://drive.google.com/file/d/114wqampf0aupHSm5dvoRt8UTRK4uOCov/view

Presentación: https://drive.google.com/file/d/1bjJN5KYD8F2-oNR1mg-lF_sZfjsGeMmY/view